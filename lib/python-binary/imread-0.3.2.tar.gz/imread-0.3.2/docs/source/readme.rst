======
IMREAD
======

This is library to read & write image files.


