import warnings
warnings.warn(
'''Use

from mahotas.features import zernike
''', DeprecationWarning)

from mahotas.features.zernike import *
