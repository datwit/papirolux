EllipseFitter is a package to find best fit ellipses of binary images (uses sqrts of principle moments) from David Mashburn including port of ImageJ java code written by Bob Rodieck.
