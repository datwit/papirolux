ImageContour is a package to aid in constructing and using linear paths around simply-connected binary and greyscale images.
