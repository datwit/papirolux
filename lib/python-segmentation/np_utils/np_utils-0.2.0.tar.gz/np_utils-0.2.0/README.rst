Utilities for array and list manipulation by David Mashburn.
Notably:
    functions to scale arrays by integer multiples (without interpolation)
    drawing basic graphics objects on (multi-dimensional) numpy arrays:
       line segment, triangle, circle, and sphere
